# Nutrio — phone-only APK build

This project is prepared to build a real Android APK using GitHub Actions, so no computer is required on the user's side.

1. Create/sign in to a GitHub account on your phone.
2. Create a new repository named `nutrio` (public is simplest for free Actions).
3. Upload all files/folders from this project to the repository, preserving `.github/workflows/build-apk.yml`.
4. Open the repository's **Actions** tab and select **Build Nutrio APK**.
5. Tap **Run workflow** (or push to `main` to trigger it automatically).
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run and download the **Nutrio-debug-apk** artifact.
8. Extract the downloaded artifact if necessary, then tap `app-debug.apk` and install it.

The APK is a debug-signed APK for personal installation/testing. It is not a Play Store release build.
